import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args)
    {
        Deque deque = new Deque();
//        int k=Integer.parseInt(args[1]);
////        String a = StdIn.readString();
////        System.out.println(a+k);
//
    }
}
