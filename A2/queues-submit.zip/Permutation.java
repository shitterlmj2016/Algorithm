public class Permutation {
    public static void main(String[] args)
    {Deque deque = new Deque();

    }
}
